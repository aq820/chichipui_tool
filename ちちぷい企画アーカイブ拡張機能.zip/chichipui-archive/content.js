/**
 * ちちぷい企画アーカイブ
 * ユーザー主催投稿企画の一覧ページで、各企画カードに「アーカイブ」ボタンを追加します。
 * アーカイブした企画は非表示になり、「アーカイブにした企画はこちら」ボタンで再表示できます。
 */
(() => {
  const LIST_SELECTOR = ".events-user-event__list";
  const CARD_SELECTOR = "a.events-user-event__list-item";
  const TITLE_LINK_WRAPPER_SELECTOR = ".events-user-event__page-title-link-wrapper";
  const STORAGE_KEY = "archivedEventIds";

  /** @type {Set<string>} アーカイブ済み企画ID */
  let archived = new Set();
  /** アーカイブした企画を表示中かどうか */
  let showArchived = false;

  const list = document.querySelector(LIST_SELECTOR);
  if (!list) return; // 一覧ページ以外では何もしない

  /** カードのhrefから企画IDを取り出す */
  function getEventId(card) {
    const href = card.getAttribute("href") || "";
    const m = href.match(/\/events\/user-events\/([0-9a-f-]{36})\/?/i);
    return m ? m[1] : href;
  }

  /** アーカイブ状態を chrome.storage.local に保存 */
  function save() {
    chrome.storage.local.set({ [STORAGE_KEY]: Array.from(archived) });
  }

  /** 全カードの表示状態・ボタン表記・件数表示を更新 */
  function applyStates() {
    const cards = document.querySelectorAll(CARD_SELECTOR);
    let count = 0;
    cards.forEach((card) => {
      const id = card.dataset.cpaId;
      const isArchived = archived.has(id);
      if (isArchived) count++;
      card.classList.toggle("cpa-archived", isArchived);
      card.classList.toggle("cpa-hidden", isArchived && !showArchived);
      const btn = card.querySelector(".cpa-archive-btn");
      if (btn) {
        btn.textContent = isArchived ? "アーカイブ解除" : "アーカイブ";
        btn.classList.toggle("cpa-archive-btn--archived", isArchived);
      }
    });
    const toggleBtn = document.querySelector(".cpa-toggle-btn");
    if (toggleBtn) {
      toggleBtn.textContent = showArchived
        ? `アーカイブを閉じる（${count}件）`
        : `アーカイブにした企画はこちら（${count}件）`;
      toggleBtn.classList.toggle("cpa-toggle-btn--active", showArchived);
    }
  }

  /** 各企画カードにアーカイブボタンを付与 */
  function setupCards() {
    document.querySelectorAll(CARD_SELECTOR).forEach((card) => {
      if (card.dataset.cpaId) return; // 設定済み
      card.dataset.cpaId = getEventId(card);

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cpa-archive-btn";
      btn.textContent = "アーカイブ";
      btn.addEventListener("click", (e) => {
        // カード全体が<a>なので、リンク遷移を止める
        e.preventDefault();
        e.stopPropagation();
        const id = card.dataset.cpaId;
        if (archived.has(id)) {
          archived.delete(id);
        } else {
          archived.add(id);
        }
        save();
        applyStates();
      });
      card.appendChild(btn);
    });
  }

  /** 「企画の開催はこちら」の下にトグルボタンを設置 */
  function setupToggleButton() {
    if (document.querySelector(".cpa-toggle-btn")) return;

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "cpa-toggle-btn";
    btn.textContent = "アーカイブにした企画はこちら";
    btn.addEventListener("click", () => {
      showArchived = !showArchived;
      applyStates();
    });

    const holder = document.createElement("div");
    holder.className = "cpa-toggle-wrapper";
    holder.appendChild(btn);

    const wrapper = document.querySelector(TITLE_LINK_WRAPPER_SELECTOR);
    if (wrapper) {
      wrapper.insertAdjacentElement("afterend", holder);
    } else {
      list.insertAdjacentElement("beforebegin", holder);
    }
  }

  // 保存済みのアーカイブ状態を読み込んで初期化
  chrome.storage.local.get(STORAGE_KEY, (data) => {
    archived = new Set(data[STORAGE_KEY] || []);
    setupCards();
    setupToggleButton();
    applyStates();
  });
})();
