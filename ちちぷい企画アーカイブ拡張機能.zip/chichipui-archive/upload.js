/**
 * ちちぷい企画アーカイブ - 投稿(アップロード)ページ用
 * 「ユーザー主催投稿企画」のチェックボックス一覧から、
 * アーカイブ済みの企画の行を非表示にします。
 * 一覧はVueで動的に描画されるため、MutationObserverで変化を監視します。
 */
(() => {
  const STORAGE_KEY = "archivedEventIds";
  const UUID_RE = /\/events\/user-events\/([0-9a-f-]{36})\/?/i;

  /** @type {Set<string>} アーカイブ済み企画ID */
  let archived = new Set();
  /** アーカイブ済みの行を一時的に表示中かどうか */
  let showArchived = false;

  /** ユーザー主催投稿企画のチェックボックス行を取得 */
  function findRows() {
    const anchors = document.querySelectorAll(
      "label.checkbox a[href*='/events/user-events/']"
    );
    const rows = [];
    anchors.forEach((a) => {
      const row = a.closest("div.is-flex");
      if (row) rows.push({ a, row });
    });
    return rows;
  }

  /** 行の表示状態とトグルリンクを更新 */
  function apply() {
    const rows = findRows();
    let count = 0;
    let container = null;
    rows.forEach(({ a, row }) => {
      const m = (a.getAttribute("href") || "").match(UUID_RE);
      const id = m ? m[1] : null;
      const isArchived = id !== null && archived.has(id);
      if (isArchived) count++;
      const hide = isArchived && !showArchived;
      row.classList.toggle("cpa-upload-archived", isArchived);
      row.classList.toggle("cpa-upload-hidden", hide);
      // Bulmaの .is-flex は display:flex !important のため、
      // インラインスタイルの !important で確実に上書きする
      if (hide) {
        row.style.setProperty("display", "none", "important");
      } else {
        row.style.removeProperty("display");
      }
      if (!container) container = row.parentElement;
    });
    updateToggle(count, container);
  }

  /** 「アーカイブ済みの企画を表示（N件）」トグルの設置・更新 */
  function updateToggle(count, container) {
    let btn = document.querySelector(".cpa-upload-toggle");
    if (!container || count === 0) {
      if (btn) btn.remove();
      return;
    }
    if (!btn) {
      btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cpa-upload-toggle";
      btn.addEventListener("click", () => {
        showArchived = !showArchived;
        apply();
      });
    }
    btn.textContent = showArchived
      ? `アーカイブ済みの企画を隠す（${count}件）`
      : `アーカイブ済みの企画を表示（${count}件）`;
    // セクション（div.field）の末尾に設置（Vueの再描画で消えたら再設置される）
    if (btn.parentElement !== container) {
      container.appendChild(btn);
    }
  }

  /** Vueの再描画（セクション開閉・年齢制限切替など）を監視 */
  function observe() {
    let scheduled = false;
    const observer = new MutationObserver(() => {
      if (scheduled) return;
      scheduled = true;
      requestAnimationFrame(() => {
        scheduled = false;
        apply();
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  // 一覧ページ側での変更（アーカイブ追加・解除）を即時反映
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[STORAGE_KEY]) {
      archived = new Set(changes[STORAGE_KEY].newValue || []);
      apply();
    }
  });

  chrome.storage.local.get(STORAGE_KEY, (data) => {
    archived = new Set(data[STORAGE_KEY] || []);
    console.log(
      `[ちちぷい企画アーカイブ] 起動: アーカイブ ${archived.size} 件を読み込みました`
    );
    apply();
    observe();
  });
})();
